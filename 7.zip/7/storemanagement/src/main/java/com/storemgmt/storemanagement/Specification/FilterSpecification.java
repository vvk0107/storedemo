package com.storemgmt.storemanagement.Specification;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.storemgmt.storemanagement.dto.SearchRequestDto;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
@Service
public class FilterSpecification<T> {
		public Specification<T> getSearchSpecification(SearchRequestDto searchRequestDto){
			return new Specification<T>() {
				
				@Override
				public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
					return criteriaBuilder.equal(root.get(searchRequestDto.getColumn()), searchRequestDto.getValue());
				}
			};
		}
		public Specification<T> getSearchSpecification(List<SearchRequestDto> searchRequestDtos){
			return (root, query, criteriaBuilder) -> {
				List<Predicate> predicates = new ArrayList<>();
				for(SearchRequestDto requestDto : searchRequestDtos) {
					Predicate equal = criteriaBuilder.equal(root.get(requestDto.getColumn()), requestDto.getValue());
					predicates.add(equal);
					
				}
				return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
			};
		}
	}