package com.storemgmt.storemanagement.exception;

public class PriceException extends  RuntimeException{		
	private static final long serialVersionUID = 1L;
	private String Message;
	public PriceException() {		
	}
	public PriceException(String msg) {
		super(msg);
		this.Message=msg;		
	}
         	

}
