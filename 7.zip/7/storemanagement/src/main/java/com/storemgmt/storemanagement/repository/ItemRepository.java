package com.storemgmt.storemanagement.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.storemgmt.storemanagement.entity.Item;


@Repository
public interface ItemRepository extends JpaRepository<Item, Integer>, JpaSpecificationExecutor<Item>
 {
	@Query("Select i from Item i order by i.itemNumber Asc")
	public List<Item> findAllOrderBy(LocalDate SellingDate);
	public List<Item> findAllOrderBy();

	public List<Item> findBySellingDate(LocalDate SellingDate);
	public List<Item> findAll();
//
}
