package com.storemgmt.storemanagement.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;
import com.storemgmt.storemanagement.Specification.FilterSpecification;
import com.storemgmt.storemanagement.dto.RequestDto;
import com.storemgmt.storemanagement.entity.Item;
import com.storemgmt.storemanagement.exception.ErrorResponse;
import com.storemgmt.storemanagement.exception.ItemAlreadyPresent;
import com.storemgmt.storemanagement.exception.LowQuantityException;
import com.storemgmt.storemanagement.exception.NoItemPresent;
import com.storemgmt.storemanagement.exception.PriceException;
import com.storemgmt.storemanagement.repository.ItemRepository;
import com.storemgmt.storemanagement.service.ItemService;

import jakarta.validation.Valid;


@RestController
public class ItemController {
	@Autowired
	private ItemService service;
	
	@Autowired
	private ItemRepository itemrepository;
	
	@Autowired
	private FilterSpecification<Item> itemFilterSpecification;
	
	
	@PostMapping("/addItem")
	public String saveItem(@RequestBody @Valid Item item) {
		service.createItem(item);
		return "Item added";
	}
	
	@PutMapping("/updateItem")
	public String updateitem(@RequestBody Item item) {
			return service.updateItem(item);
			
	}
	@GetMapping("/getAllItems")
		public List<Item> getAllItems(){
		return service.getAllItems();
	}
	
	@DeleteMapping("/deleteItem/{ItemNumber}")
	public String deleteitem(@PathVariable Integer ItemNumber)
	
	{
		 service.deleteItem(ItemNumber);
		 return "Item deleted sucessfully : " + ItemNumber ;
	
	}
//	@GetMapping("/searchItem/{itemNumber}")
//	public Item searchitem(@PathVariable int ItemNumber) {
//		return service.getItemById(ItemNumber);
//	}
	@PostMapping("/sellItem/{itemId}/{soldQuantity}")
	public String sellItem(@PathVariable Integer itemId, @PathVariable Integer soldQuantity) {
		service.sellItem(itemId, soldQuantity);
		return "Item sold sucessfully";
	}
	
	
	@GetMapping("/getprofit/{date}")
	public String getProfit(@PathVariable LocalDate date){
	return service.dailyProfit(date);
}
	@PostMapping("/search")
	public List<Item> getItems(@RequestBody RequestDto requestDto) {		
		Specification<Item> searchSpecification = itemFilterSpecification.getSearchSpecification(requestDto.getSearchRequestDto());
		return itemrepository.findAll(searchSpecification);
		
		
	}
	
	
	
	@ExceptionHandler(value= ItemAlreadyPresent.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ErrorResponse handleItemAlreadyPresent(ItemAlreadyPresent e) {
		return new ErrorResponse(HttpStatus.NOT_FOUND.value(),e.getMessage());
	}
	
	@ExceptionHandler(value= NoItemPresent.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ErrorResponse handleNoItemPresent(NoItemPresent e) {
		return new ErrorResponse(HttpStatus.NOT_FOUND.value(),e.getMessage());
	}
	
	@ExceptionHandler(value= LowQuantityException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ErrorResponse handleLowQuantityException(LowQuantityException e) {
		return new ErrorResponse(HttpStatus.NOT_FOUND.value(),e.getMessage());
	}
	@ExceptionHandler(value= PriceException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ErrorResponse handlePriceExceptionException(PriceException e) {
		return new ErrorResponse(HttpStatus.NOT_FOUND.value(),e.getMessage());
	}


}
