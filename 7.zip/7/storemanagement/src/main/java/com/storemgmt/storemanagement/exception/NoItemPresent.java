package com.storemgmt.storemanagement.exception;
	
	public class NoItemPresent extends RuntimeException{		
		private static final long serialVersionUID = 1L;
		private String Message;
		public NoItemPresent() {		
		}
		public NoItemPresent(String msg) {
			super(msg);
			this.Message=msg;		
		}
    	

	}

