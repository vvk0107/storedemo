package com.storemgmt.storemanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import com.storemgmt.storemanagement.entity.Item;
import com.storemgmt.storemanagement.exception.ItemAlreadyPresent;
import com.storemgmt.storemanagement.exception.LowQuantityException;
import com.storemgmt.storemanagement.exception.NoItemPresent;
import com.storemgmt.storemanagement.exception.PriceException;
import com.storemgmt.storemanagement.repository.ItemRepository;


@Service
public class ItemService {
	@Autowired 
	private ItemRepository itemrepository;
	
	Item item = new Item();
	Optional <Long> LastProfit=Optional.ofNullable(item.getTotalProfit());
		
	public String createItem(Item item) {
	    Item newitem= new Item();
	    
	    newitem.setItemNumber(item.getItemNumber());
	    newitem.setItemName(item.getItemName());
	    newitem.setItemCostPrice(item.getItemCostPrice());
	    newitem.setItemSellingPrice(item.getItemSellingPrice());
	    newitem.setQuantity(item.getQuantity());
	    newitem.setExpirydate(item.getExpirydate());
	    newitem.setStoreNumber(item.getStoreNumber());
	    // Check if selling price is less than cost price
	    if (newitem.getItemSellingPrice() < newitem.getItemCostPrice()) {
	        throw new PriceException("Selling price should not be less than cost price");
	    }
	    //check if already item number is present
	    itemrepository.findById(newitem.getItemNumber()).ifPresent(consumer -> {
	        throw new ItemAlreadyPresent("Item already exists");
	    });
	    itemrepository.save(newitem);
	    return "item added";
	}
	
	
	public List<Item> getAllItems(){
		return itemrepository.findAllOrderBy();
	}
	

	public String updateItem(Item item) {
		Item newitem= new Item();
		
		newitem.setItemNumber(item.getItemNumber());
		newitem.setItemName(item.getItemName());
		newitem.setItemCostPrice(item.getItemCostPrice());
		newitem.setItemSellingPrice(item.getItemSellingPrice());
		newitem.setQuantity(item.getQuantity());
		newitem.setExpirydate(item.getExpirydate());
		newitem.setStoreNumber(item.getStoreNumber());
		itemrepository.findById(newitem.getItemNumber()).orElseThrow(()->
			new ItemAlreadyPresent("No Item Available to update"));
		itemrepository.save(newitem);
			return "item updated";
			
	}
	public String deleteItem(Integer ItemNumber){
		if(itemrepository.existsById(ItemNumber))
			{	 
				itemrepository.deleteById(ItemNumber);
			}else {				 
				throw new NoItemPresent("No Such Item Present");
			}
			return "Successfully deleted Item: " +ItemNumber;
		}
	
//	public Item getItemById(Integer ItemNumber) {
//			return itemrepository.findById(ItemNumber).orElseThrow(()->
//							new NoItemPresent("No Store Present"));
//					}
//	
	
	public Item sellItem(Integer itemId, Integer soldQuantity) {	
			Item sellItem=itemrepository.findById(itemId).orElseThrow(()-> new NoItemPresent("No Such Item Present"));
		if(LastProfit.isPresent()) {
				LastProfit.ofNullable(sellItem.getTotalProfit());
			}
		if( sellItem.getQuantity()<soldQuantity) {
				throw new LowQuantityException("Low quantity in Inventrory");
			}
		LocalDate date = LocalDate.now();	
		Integer prevQuantity=sellItem.getSellquantity();
		sellItem.setQuantity(sellItem.getQuantity()-soldQuantity);
		sellItem.setSellingDate(date);
		if(prevQuantity!=null) {
		sellItem.setSellquantity(prevQuantity+soldQuantity);
		}
			else {
				sellItem.setSellquantity(soldQuantity);
			}
			itemrepository.save(sellItem);
			return sellItem;
		}


	public String dailyProfit(LocalDate SellingDate) {
		List<Item> sellItem=itemrepository.findBySellingDate(SellingDate);
		Long profit=0L;
		Long TotalProfit=0L;
		if(sellItem==null) {
			throw new NoItemPresent("No item sold Today");			
		}else {
			for(Item value: sellItem) {
				profit=value.getSellquantity()*(value.getItemSellingPrice()-value.getItemCostPrice());	
				TotalProfit+=profit;
				value.setTotalProfit(profit);
				itemrepository.findById(value.getItemNumber());
				itemrepository.save(value);
				}			
			}			
			return "Today's Profit is " +TotalProfit;	
		}
}



