package com.storemgmt.storemanagement.Validator;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class NumberValidator implements ConstraintValidator<NumberConstraint, String> {

    @Override
    public void initialize(NumberConstraint number) {
    }

    @Override
    public boolean isValid(String numberField, ConstraintValidatorContext cxt) {
        if (numberField != null) {
            return numberField.matches("[0-9]+");
        }
        return false;
    }
}
