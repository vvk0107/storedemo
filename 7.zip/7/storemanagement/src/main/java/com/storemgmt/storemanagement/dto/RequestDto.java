package com.storemgmt.storemanagement.dto;

import java.util.List;

public class RequestDto {
	private List<SearchRequestDto> searchRequestDto;
	//can filter using different operators

	public List<SearchRequestDto> getSearchRequestDto() {
		return searchRequestDto;
	}

	public void setSearchRequestDto(List<SearchRequestDto> searchRequestDto) {
		this.searchRequestDto = searchRequestDto;
	}


}
