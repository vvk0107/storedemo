package com.storemgmt.storemanagement.entity;

import java.sql.Date;
import java.time.LocalDate;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;

import org.springframework.format.annotation.DateTimeFormat;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;


@Entity 
@Table(name="Item")
public class Item {
	
	@Id
	
	private Integer itemNumber;
	@NotBlank(message = "itemName shouldn't be null or empty")
	private String itemName;
	@Positive(message = "add in numbers only")
//	@NumberConstraint
//	@Pattern(regexp = "^[0-9]$")
//	@NotEmpty(message = "itemCostPrice shouldn't be null or empty")
	@Positive(message = "add in numbers only")
	private Long itemCostPrice;
	@Positive(message = "add in numbers only")
	private Long itemSellingPrice;
	@Positive(message = "add in numbers only")
	private Integer storeNumber;
	@Positive(message = "add in numbers only")
	private Integer quantity;
	@Positive(message = "add in numbers only")
	private Integer sellquantity;
	@Future(message = "expirydate shoudn't be before current date")
	@DateTimeFormat(pattern="dd-MM-yyyy")
	private Date expirydate;
	@DateTimeFormat(pattern="dd-MM-yyyy")
	private LocalDate sellingDate;
	@Column
	private Long totalProfit;
	public Integer getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(Integer itemNumber) {
		this.itemNumber = itemNumber;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Long getItemCostPrice() {
		return itemCostPrice;
	}
	public void setItemCostPrice(Long itemCostPrice) {
		this.itemCostPrice = itemCostPrice;
	}
	public Long getItemSellingPrice() {
		return itemSellingPrice;
	}
	public void setItemSellingPrice(Long itemSellingPrice) {
		this.itemSellingPrice = itemSellingPrice;
	}
	public Integer getStoreNumber() {
		return storeNumber;
	}
	public void setStoreNumber(Integer storeNumber) {
		this.storeNumber = storeNumber;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Integer getSellquantity() {
		return sellquantity;
	}
	public void setSellquantity(Integer sellquantity) {
		this.sellquantity = sellquantity;
	}
	public Date getExpirydate() {
		return expirydate;
	}
	public void setExpirydate(Date expirydate) {
		this.expirydate = expirydate;
	}
	public LocalDate getSellingDate() {
		return sellingDate;
	}
	public void setSellingDate(LocalDate sellingDate) {
		this.sellingDate = sellingDate;
	}
	public Long getTotalProfit() {
		return totalProfit;
	}
	public void setTotalProfit(Long totalProfit) {
		this.totalProfit = totalProfit;
	}
	public Item(Integer itemNumber, @NotBlank(message = "itemName shouldn't be null or empty") String itemName,
			@Positive(message = "add in numbers only") @Positive(message = "add in numbers only") Long itemCostPrice,
			@Positive(message = "add in numbers only") Long itemSellingPrice,
			@Positive(message = "add in numbers only") Integer storeNumber,
			@Positive(message = "add in numbers only") Integer quantity,
			@Positive(message = "add in numbers only") Integer sellquantity,
			@Future(message = "expirydate shoudn't be before current date") Date expirydate, LocalDate sellingDate,
			Long totalProfit) {
		super();
		this.itemNumber = itemNumber;
		this.itemName = itemName;
		this.itemCostPrice = itemCostPrice;
		this.itemSellingPrice = itemSellingPrice;
		this.storeNumber = storeNumber;
		this.quantity = quantity;
		this.sellquantity = sellquantity;
		this.expirydate = expirydate;
		this.sellingDate = sellingDate;
		this.totalProfit = totalProfit;
	}
	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}


	
	
}