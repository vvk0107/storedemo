package com.storemgmt.store.exception;
	
	public class LowQuantityException extends RuntimeException{		
		private static final long serialVersionUID = 1L;
		private String Message;
		public LowQuantityException() {		
		}
		public LowQuantityException(String msg) {
			super(msg);
			this.Message=msg;		
		}
    	

	}

