package com.storemgmt.store.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity 
@Table(name="Store")
public class Store {
	
	
	@Id
	private Integer storeNumber;
	private String storeName;

	@Column
	private Long storeProfit;

	public Integer getStoreNumber() {
		return storeNumber;
	}

	public void setStoreNumber(Integer storeNumber) {
		this.storeNumber = storeNumber;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public Long getStoreProfit() {
		return storeProfit;
	}

	public void setStoreProfit(Long storeProfit) {
		this.storeProfit = storeProfit;
	}

	public Store(Integer storeNumber, String storeName, Long storeProfit) {
		super();
		this.storeNumber = storeNumber;
		this.storeName = storeName;
		this.storeProfit = storeProfit;
	}

	public Store() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	
}