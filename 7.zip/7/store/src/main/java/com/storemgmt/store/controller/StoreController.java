package com.storemgmt.store.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.storemgmt.store.entity.Store;
import com.storemgmt.store.exception.ErrorResponse;
import com.storemgmt.store.exception.NoStorePresent;
import com.storemgmt.store.exception.StoreAlreadyPresent;
import com.storemgmt.store.service.StoreService;

@RestController
public class StoreController {
	
	@Autowired
	private StoreService service;
	
	@PostMapping("/addstore")
	public String savestore(@RequestBody Store store){
		return service.saveStore(store);	}
	
	@GetMapping("/searchAllstore")
	public List<Store> searchAllStore(){
		return service.getAllstores();
	}
	
	@GetMapping("/searchStores")
    public List<Integer> searchStores(){
        return service.getStoreNumbers();
    }

	
	@GetMapping("/searchStore/{storeNumber}")
	public Store searchstore(@PathVariable int StoreNumber) {
		return service.getstoreById(StoreNumber);
	}
	@PutMapping("/updatestore")
	public String updatestore(@RequestBody Store store) {
			return service.updateStore(store);
	}
	@DeleteMapping("/delete/{storeNumber}")
	public String deletestore(@PathVariable int storeNumber) {
			return service.deleteStore(storeNumber);
			
	
	}
	@GetMapping("/getAllItems")
	public ResponseEntity<String> getAllItems() {
		return service.allItems();
		
	}
	@ExceptionHandler(value= StoreAlreadyPresent.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ErrorResponse handleStoreAlreadyPresent(StoreAlreadyPresent s) {
		return new ErrorResponse(HttpStatus.NOT_FOUND.value(),s.getMessage());
	
	}
	@ExceptionHandler(value= NoStorePresent.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ErrorResponse handleNoStorePresent(NoStorePresent s) {
		return new ErrorResponse(HttpStatus.NOT_FOUND.value(),s.getMessage());
	
	}
}

