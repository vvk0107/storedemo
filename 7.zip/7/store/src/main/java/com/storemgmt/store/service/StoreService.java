package com.storemgmt.store.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.storemgmt.store.entity.Item;
import com.storemgmt.store.entity.Store;
import com.storemgmt.store.exception.NoStorePresent;
import com.storemgmt.store.exception.StoreAlreadyPresent;
import com.storemgmt.store.repository.ItemRepository;
import com.storemgmt.store.repository.StoreRepository;

@Service
public class StoreService {

@Autowired 
private StoreRepository storerepository;
			
public String saveStore(Store store) {
		Store storeNew= new Store();
				
		storeNew.setStoreNumber(store.getStoreNumber());
		storeNew.setStoreName(store.getStoreName());
		storeNew.setStoreProfit(store.getStoreProfit());				
		storerepository.findById(store.getStoreNumber()).ifPresent(consumer->{
				throw new StoreAlreadyPresent("Store already exists");});
		storerepository.save(store);
				return "Store added";
			}
public List<Store> getAllstores() {
	return storerepository.findAll();
			    }
			
public List<Integer> getStoreNumbers() {
	return storerepository.findStores();
		    }

public Store getstoreById(int StoreNumber) {
	return storerepository.findById(StoreNumber).orElseThrow(()->
					new NoStorePresent("No Store Present"));
			}
			
public String deleteStore(int StoreNumber) {
			try {
				if (storerepository.existsById(StoreNumber))
					{
					storerepository.deleteById(StoreNumber);
					return "Product deleted sucessfully:  " + StoreNumber;	
					}
					return ("No store available for this ID to delete");
				}catch(IllegalArgumentException e) {
					return ("Illegal Argument");
				}
				}
			

public String updateStore(Store store) {
	Store storeNew= new Store();				
	storeNew.setStoreNumber(store.getStoreNumber());
	storeNew.setStoreName(store.getStoreName());
	storeNew.setStoreProfit(store.getStoreProfit());
			
				
	storerepository.findById(store.getStoreNumber()).orElseThrow(()->
	new NoStorePresent("No store Available to update"));
		storerepository.save(store );
		return "store updated";
	}


	//method to get item inventory
RestTemplate restTemplate = new RestTemplate();
public static final String get_All_items_URL = "http://localhost:8080/getAllItems";

public ResponseEntity<String> allItems(Item item){
	HttpHeaders headers = new HttpHeaders();
	headers.setAccept (Arrays.asList(MediaType.APPLICATION_JSON));
	HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
	ResponseEntity<String> response = restTemplate.exchange(get_All_items_URL, HttpMethod.GET, entity, String.class);
	restTemplate.postForObject(get_All_items_URL,item,Item.class);
	System.out.println("Item: "+ item);
			return response;
	
}


public Store findAll() {
				// TODO Auto-generated method stub
				return null;
			}
	

}