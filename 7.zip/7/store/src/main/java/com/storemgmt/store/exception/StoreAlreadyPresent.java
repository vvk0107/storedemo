package com.storemgmt.store.exception;
	
	public class StoreAlreadyPresent extends RuntimeException{		
		private static final long serialVersionUID = 1L;
		private String Message;
		public StoreAlreadyPresent() {		
		}
		public StoreAlreadyPresent(String msg) {
			super(msg);
			this.Message=msg;		
		}
	         	

	}

