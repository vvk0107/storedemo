package com.storemgmt.store.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.storemgmt.store.entity.Store;

@Repository
public interface StoreRepository extends JpaRepository <Store,Integer> {
		@Query("Select s.storeNumber from Store s")
	    List<Integer> findStores();
		
		Store findByStoreNumber(Integer storeNumber);
	}

