package com.storemgmt.store.entity; 

import java.sql.Date;
import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;

public class Item {

	
	private Integer itemNumber;
	private String itemName;
	private Long itemCostPrice;
	private Long itemSellingPrice;
	private Integer StoreNumber;
	private Integer quantity;
	private Integer sellquantity;
	@DateTimeFormat(pattern="dd-MM-yyyy")
	private Date expirydate;
	@DateTimeFormat(pattern="dd-MM-yyyy")
	private LocalDate sellingDate;
	private Long totalProfit;
	public Integer getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(Integer itemNumber) {
		this.itemNumber = itemNumber;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Long getItemCostPrice() {
		return itemCostPrice;
	}
	public void setItemCostPrice(Long itemCostPrice) {
		this.itemCostPrice = itemCostPrice;
	}
	public Long getItemSellingPrice() {
		return itemSellingPrice;
	}
	public void setItemSellingPrice(Long itemSellingPrice) {
		this.itemSellingPrice = itemSellingPrice;
	}
	public Integer getStoreNumber() {
		return StoreNumber;
	}
	public void setStoreNumber(Integer storeNumber) {
		StoreNumber = storeNumber;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Integer getSellquantity() {
		return sellquantity;
	}
	public void setSellquantity(Integer sellquantity) {
		this.sellquantity = sellquantity;
	}
	public Date getExpirydate() {
		return expirydate;
	}
	public void setExpirydate(Date expirydate) {
		this.expirydate = expirydate;
	}
	public LocalDate getSellingDate() {
		return sellingDate;
	}
	public void setSellingDate(LocalDate sellingDate) {
		this.sellingDate = sellingDate;
	}
	public Long getTotalProfit() {
		return totalProfit;
	}
	public void setTotalProfit(Long totalProfit) {
		this.totalProfit = totalProfit;
	}
	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}