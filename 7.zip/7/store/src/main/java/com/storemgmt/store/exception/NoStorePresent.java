package com.storemgmt.store.exception;
	
	public class NoStorePresent extends RuntimeException{		
		private static final long serialVersionUID = 1L;
		private String Message;
		public NoStorePresent() {		
		}
		public NoStorePresent(String msg) {
			super(msg);
			this.Message=msg;		
		}
    	

	}

