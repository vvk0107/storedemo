package com.storemgmt.store.exception;

public class ErrorResponse {
	
		private Integer status;
		private String message;
		public ErrorResponse(String msg) {
			super();
			this.message=msg;
		}
		public Integer getStatus() {
			return status;
		}
		public void setStatus(Integer status) {
			this.status = status;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public ErrorResponse(Integer status, String message) {
			super();
			this.status = status;
			this.message = message;
		}
		public ErrorResponse() {
			super();
			// TODO Auto-generated constructor stub
		}
		
	} 

